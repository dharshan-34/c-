#include<iostream>
using namespace std;
int main(){
    int l,b;
    int l1,b1;
    int l2,b2;
    cin>>l>>b;
    cin>>l1>>l1;
    cin>>l2>>b2;
    if((l1+l2<=l&&b1+b2<=b)||(l1+l2<=b&&b1+b2<=l)){
        cout<<"Raj can fix both painting";
    }
    else{
        cout<<"Raj cannot fix both painting";
    }
    
}