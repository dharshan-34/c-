#include<iostream>
using namespace std;
int main()
{
    int length,breadth;
    cin>>length>>breadth;
    int ropelength=2*(length+breadth);
    int carpetarea=length*breadth;
    cout<<ropelength<<endl;
    cout<<carpetarea<<endl;
    return 0;
}
