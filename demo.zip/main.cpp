#include<iostream>
using namespace std;
int main(){
    int n=5;
    int m=11;
    cin>>n;
    for(int i=0;i<=n;i++){
        cout<<m*m<<" ";
        m=m+4;
        
    }
}