#include<iostream>
using namespace std;
int main()
{
    int r,x;
    cin>>r>>x;
    int diameter=2*r;
    if(diameter<=x){
        cout<<"circle can be inside a Square"<<endl;
    }
    else{
        cout<<"circle cannot be inside a Square"<<endl;
    }
}