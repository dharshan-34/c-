#include<iostream>
using namespace std;
int main(){
    int a,b;
    cin>>a>>b;
    int max=(a>b)?a:b;
 
        cout<<(a>b?"a is greater":"b is greater")<<endl;
    
cout<<max;
return 0;
}
