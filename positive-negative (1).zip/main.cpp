#include<iostream>
using namespace std;
int main()
{
    int x,y,z;
    cin>>x>>y>>z;
    if(x>0&&y>0){
        cout<<"I quradant"<<endl;
    }
    else if(x<0&&y>0){
        cout<<" II quadrant"<<endl;
    }
    else if(x>0&&y<0){
        cout<<"III quardant"<<endl;
    }
    else if(x<0&&y<0){
        cout<<"Iv quardant"<<endl;
    }
    else if(x==0&&y==0){
        cout<<"equal"<<endl;
    }
}