/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
int main(){
    int  f1,f2,f3;
    int a1,a2,a3;
    int s1,s2,s3;
    cin>>f1>>f2>>f3;
    cin>>a1>>a2>>a3;
    cin>>s1>>s2>>s3;
    int f=f1+f2+f3;
    int a=a1+a2+a3;
    int s=s1+s2+s3;
    cout<<"in flipkart"<<endl;
    cout<<" in amazon"<<endl;
    cout<<"in snapdeal"<<endl;
    if(f<(a&&s)){
        cout<<" best is flipkart";
    }
    else if(a<(f&&s)){
        cout<<"best is amazon";
    }
    else{
        cout<<"best is snapdeal";
    }
}
    std::cout<<"Hello World";

    return 0;
}