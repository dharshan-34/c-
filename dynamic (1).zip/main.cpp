#include<iostream>
using namespace std;
int main(){
    int a=5;
    int*ptr=new int;
    *ptr=5;
    cout<<*ptr;
    delete ptr;
    cout<<endl<<*ptr;
    return 0;
}