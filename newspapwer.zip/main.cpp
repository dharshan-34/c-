#include<iostream>
using namespace std;
int main()
{
     int w,x,y;
     cin>>w>>y>>x;
     int total_sold=w*x;
     int total_cost=w*y+100;
     int profit=total_sold-total_cost;
     cout<<profit<<endl;
     return 0;
     
     
}