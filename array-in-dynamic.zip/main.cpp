#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    //int arr[n];80
    int *arr=new int[n];//dynamic memory allocation
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    for(int i=0;i<n;i++){
        cout<<arr[i]<<" ";
    }
    delete[] arr;
    cout<<"New array size";
    return 0;
    }