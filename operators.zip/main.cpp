#include<iostream>
using namespace std;
int main(){
    int totalstudent,totalteam;
    cin>>totalstudent>>totalteam;
    int studentperteam=totalstudent/totalteam;
    int leftoutstudent=totalstudent%totalteam;
    cout<<studentperteam<<endl;
    cout<<leftoutstudent<<endl;
    return 0;
}